The Circle Game Returns
By El Loco
Bugsplat Games

This is a small game which El Loco made which entails two circles, no longer shooting each other as they were in the rather crap prequel, but now playing a harmless game of tag. If you would like a game with a storyline, go to the following section. If you just want to play a shallow game of tag, not knowing whose lives you may be affecting, join the rest of the world at the section after that, named 'No Story'.


Story:

Red hates Blue.
Blue hates Red.
One day, the two rivals were shooting at each other (see 'Circle Game', under the minigames section at bugsplat.tk). They shot and shot and shot, not caring about one little concerning factor: ammo. Suddenly, the two circles ran out of ammunition, and could no longer shoot each other. 
It was here that the third character, Green, came in.
Green is slightly smaller than Blue and Red.
He doesn't really care about the fight.
Green, however, is really annoying.
He lynched onto Red, and before he knew it, started whining about everything. Red was so annoyed that he ran up to Blue, and passed Green on to him. Red and Blue discovered that Green quite enjoyed this passtime, and that the only way to stop him from whining was to chase each other around. Green aggreed that he would jump to the other circle if the circle touching him touched the other.

And now, they are endlessly held in an epic battle, closely resembling a shallow game of tag.


No Story (rules):

The circle who is it has to hit the circle who is not it. 
The green circle means that you are it. 
You don't want to be it.
When you are hit, you become it.
When you become it, you are dormant for a small amount of time, which can be changed in the data.dat file.



Control (keys):

Red:
	Up    - Up key
	Down  - Down key
	Left  - Left key
	Right - Right key

Blue:
	Up    - W key
	Down  - S key
	Left  - A key
	Right - D key

	Exit  - Escape key



Bending the rules (data.dat):
	You can change the numbers that are used by the program by editing 'data.dat'
	Simply open it in notepad or wordpad or other editor, and change the numbers that are there.
	The First line tells you what the rest of the lines do.


	Speed (1st number) is the rate at which the velocity grows (times by the number that you enter there) when accelerating
	Slowdown (2nd number) is the rate at which the velocity decreases because of 'air friction'
	Bounce (3rd number) is the decimal of the velocity when you hit a wall, i.e 0.8 means that when you hit a wall, you bounce off at 'v * 0.8' in the opposite direction.
	DormantTime (4th number) is the length of time that you are dormant when you get tagged
	Collision (5th number) is the distance away which you have to be to hit the opponent. Don't change this unless you know what you're doing.
	Gravity (6th number) is the strength of the gravity
	Wind (7th number) is the amount of wind that is applied (-ve goes left, +ve goes right)


Have fun playing (with a friend). Any problems send to elloco@bugsplat.tk or post on our forums (link through www.bugsplat.tk)


Bugsplat Games: Where people go to do stuff

El Loco strikes again!